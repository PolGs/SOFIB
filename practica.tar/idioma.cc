#include "idioma.hh"
using namespace std;

idioma::idioma(){}


void idioma::modificar_idioma(){    
    frequencia.leer();
    tree.crear_arbol(frequencia);
}

void idioma::consultar_tabla(){
    frequencia.escribir();
}

void idioma::consultar_codigos(){
        tree.escribir_tabla_codigos();
}

void idioma::consultar_caracter(const string& car){
    tree.consultar_caracter(car);
}

void idioma::consultar_treecode(){
    tree.escribir();
}

// void idioma::consultar_caracter(const string& car){
// 	string res;
// 	res = tree.consultar_caracter(car);
// 	if(res == "-1") cout << car << " " << res << endl;
// 	else cout << "EL idioma no existe o el caracter no eiste enn el idioma" << endl;
// }

string idioma::codifica(string& texto){
	return tree.codifica(texto);
	}
	
string idioma::decodifica(const string& texto){
	return tree.decodifica(texto);
}




// void Idioma::consultar_treecode_preorden(){
// 	treecode.recorrido_preorden();
// }
// 
// void Idioma::consultar_treecode_postorden(){
// 	treecode.recorrido_postorden();
// }
// 
// void Idioma::consultar_treecode_inorde(){
// 	treecode.recorrido_inorden();
// }



