/** @file tabla.hh
    @brief Especificación de la clase tabla
*/

#ifndef _TABLA_HH
#define _TABLA_HH

#ifndef NO_DIAGRAM 
#include <vector>
#include <string>
#include <iostream>
#endif

using namespace std;


/** @class tabla
    @brief Representa la tabla de frecuencias de un idioma.
    
    Contiene el vector que funciona como tabla y operaciones que permiten leer o escribir la tabla.
*/


class tabla{
private:
    vector<pair<string,int> > t;
public:
    
    tabla();
    
    
    /** @brief Lee una tabla
		\pre En el canal estándard de entrada se encuentra la tabla de frecuyancias a leer.
		\post Se han actualizado los datos de la tabla de frecuencias.
	*/
    void leer();
    
    /** @brief Escribe una tabla.
		\pre Cierto
		\post Se ha escrito por el canal estándard de salida una representación de la tabla.
	*/
    void escribir();
    
    int size();
    
    vector<pair<string,int> > consultar_tabla();
    
    pair<string,int> consultar_iessimo(int i);
    
};
#endif
