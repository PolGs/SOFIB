#include "cjt_idioma.hh"

cjt_idioma::cjt_idioma(){}


void cjt_idioma::anadir_idioma(const string& s){
    idioma i;
    i.modificar_idioma();
    c.insert(make_pair(s, i));
}

idioma cjt_idioma::consultar_idioma(string i){
    return c.find(i)->second;
}

bool cjt_idioma::existe_idioma(const string& i){
    map<string, idioma>::iterator it = c.find(i);
	if(it==c.end()) return false;
	else return true;
}

string cjt_idioma::codifica(const string& nombre, string& texto){
	map<string, idioma>::iterator it = c.find(nombre);
	if(it==c.end()) return "El idioma no existe";
	else return it->second.codifica(texto);
}

string cjt_idioma::decodifica(const string& nombre, const string& texto){
	map<string, idioma>::iterator it = c.find(nombre);
	if(it==c.end()) return "El idioma no existe";
	else return it->second.decodifica(texto);
}


//cout << "Codigos de " << i <<":"<<endl;
//cout << "El idioma no existe" << endl;
//map<string, idioma>::iterator it = c.find(s);
//

void cjt_idioma::consultar_codigos(const string& s){
	map<string, idioma>::iterator it = c.find(s);
    string in;
    cin >> in;
    if(in == "todos" ){
        if(it==c.end()){
            cout << "Codigos de " << s << ":"<<endl;
            cout << "El idioma no existe" << endl;
        }
        else{
            cout << "Codigos de " << s<< ":" << endl;
            idioma aux;
            aux = c.find(s)->second;
            aux.consultar_codigos();
        }
    }
    else{
        if(it==c.end()){
            cout << "Codigo de " << in << " en " << s << ":"<<endl;
            cout << "El idioma no existe o el caracter no esta en el idioma" << endl;
        }
        else{
            idioma aux;
            aux = c.find(s)->second;
            cout << "Codigo de " << in << " en " << s << ":" << endl;
            aux.consultar_caracter(in);
        }
    
    
    }
}
          


void cjt_idioma::modificar_idioma(const string& i){
    map<string, idioma>::iterator it = c.find(i);
    it->second.modificar_idioma();
}

