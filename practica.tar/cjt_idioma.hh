/** @file cjt_idioma.hh
    @brief Especificación de la clase cjt_dioma.
*/

#ifndef CJT_IDIOMA_HH
#define CJT_IDIOMA_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <map>
#endif
#include "idioma.hh"



/** @class cjt_idioma
    @brief Representa un conjunto de idomas.
    
    Contiene los idiomas y operaciones de gestión del conjunto.
*/

class cjt_idioma {

private:
    map<string, idioma> c;
    map<string, idioma>::iterator it;
public:
     /** @brief Crea un conjunto de idiomas.
		\pre Cierto
		\post Se ha creado un conjunto de idiomas vacio.
	*/
   cjt_idioma();
   
    /** @brief Elimina un conjunto de idiomas.
		\pre Cierto
		\post Se ha eliminado el conjunto de idiomas del paràmetro implicito.
	*/
    
   /** @brief Se añade al conjunto un nuevo idioma.
		\pre Al canal estándard de entrada se encuentra la tabla de frecuencias del idioma.
		\post Se ha añadido un nuevo idioma con el nombre y la tabla correspondientes.
	*/
    void anadir_idioma(const string& s);
   
   /** @brief Consulta si existe un idioma en el conjunto con el nombre del parámetro.
		\pre  
		\post Se retorna cierto si el idoma existe, falso en caso contario.
	*/
    bool existe_idioma(const string& i);
   
   
    /** @brief Consulta un idioma del conjunto.
		\pre Existe un idioma de nombre i en el conjunto.
		\post Se retorna el idioma corespondiente.
	*/
    idioma consultar_idioma(string i);//????
    
    string codifica(const string& nombre, string& texto);

    string decodifica(const string& nombre, const string& texto);

    void consultar_tabla_de_frequencias(const string& nombre);

    void consultar_treecode(const string& nombre);
    
    void modificar_idioma(const string& i);
    
    void consultar_codigos(const string& s);
   
};
#endif
