/** @file idioma.hh
    @brief Especificación de la clase idioma.
*/

#ifndef IDIOMA_HH
#define IDIOMA_HH


#ifndef NO_DIAGRAM 
#include <iostream>
#endif

#include "tabla.hh"
#include "treecode.hh"


/** @class idioma
    @brief Representa un idoma.
    
    Contiene el nombre, la tabla de frecuencias y las operaciones sobre este como modificadoras o consultoras.
*/

class idioma {

private:
    //nombre del idioma
    string nombre;
    //tabla de frecuencias del idioma
    tabla frequencia;
    //funcion que genera el treecode a partir de la tabla de frecuencias.
    
    treecode tree;
    
public:
    /** @brief Crea un nuevo idioma
		\pre cierto
		\post El resultado es un objeto de la clase idoma.
	*/
    idioma();
    

 
    /** @brief Destruye el objeto del parametro implícito.
		\pre Cierto.
		\post Se ha eliminado el objeto correspondiente.
	*/
    
     
    /** @brief Modifica la tabla de frecuencias del parametro implícito.
		\pre Al canal estandard de entrada hay una nueva tabla de frecuencias.
		\post se cambia la antigua tabla de frecuencias por la nueva.
	*/ 
    void modificar_idioma();
    
    
    /** @brief Retorna la tabla de frecuencias del parametro implícito.
		\pre Cierto
		\post Retorna la tabla del parametro implicito
	*/
    void consultar_tabla();
    
    /** @brief Retorna el treecode correspondiente 
		\pre Cierto
		\post Retorna el treecode del paramtro implicito
	*/
    void consultar_treecode();
    
    /** @brief Escribe el codigo correspondiente a un carácter o de todos los carácteres.
		\pre Cierto
		\post Se ha escrito por el canal estándard de salida el codigo pedido.
	*/
    void consultar_codigos();
    
    void consultar_caracter(const string& car);
    
    string codifica(string& text);

    string decodifica(const string& texto);

//     void consultar_treecode_preorden();
// 
//     void consultar_treecode_postorden();
// 
//     void consultar_treecode_inorden();
//     
    

    
};
#endif
