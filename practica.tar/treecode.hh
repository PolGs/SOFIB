/** @file treecode.hh
    @brief Especificación de la clase treecode
*/

#ifndef _TREECODE_HH
#define _TREECODE_HH

#ifndef NO_DIAGRAM 
#include "bintree.hh"
#include <vector>
#include "tabla.hh"
#include <string>
#include <map>
#include <set>
#include <iostream>
#endif

#include "tabla.hh"
using namespace std;

/** @class treecode
    @brief Representa el treecode de un idioma.
    
    Contiene el árbol binario de carácter/frecuencia y las operaciones sobre este como codificar, decodificar o escribir.
*/
class treecode{
    
private:
    
    BinTree<pair<string,int> > tree;
    map<string, string> codigo;
    
public:
    /**
     *  @brief Crea un nuevo objeto de la clase treecode.
     *  \pre Cierto
     *  \post Se ha creado un nuevo ojeto de la clase treecode.
     */
    treecode();
    /**
     *  @brief Elimina un objeto de la clase treecode.
     *  \pre Cierto
     *  \post Se ha eliminado el ojeto.
     */
    
        /**
     *  @brief Crea un nuevo objeto de la clase treecode a partir de una tabla.
     *  \pre T es una tabla de fecuencias válida.
     *  \post Se ha creado un nuevo treecode correspondiente a la tabla de frecuencias.
     */
    void crear_arbol(tabla &t);
    
    /** @brief Se codifica un mensaje en el idioma correspondiente
		\pre En el canal estandard de entrada se encuantra el mensaje a codificar.
		\post Si el mensaje se puede codificar se imprime por el canal estándard de salida, en caso contrario se informa de la situación. 
	*/
    string codifica(const string& texto);//en la clase tabla?
    
    /** @brief Se decodifica un mensaje en el idioma correspondiente
		\pre En el canal estandard de entrada se encuantra el mensaje a decodificar.
		\post Si el mensaje se puede decodificar se imprime por el canal estándard de salida, en caso contrario se informa de la situación. 
	*/
    string decodifica(const string& texto);
    
    /** @brief Se escribe el treecode.
		\pre Cierto
		\post Se escribe por el canal estándard de salida una representación del arbol binaro. 
	*/
    void escribir();
    
    void consultar_caracter(const string& car);
    
    void crear_codigos(const BinTree<pair<string, int>>& t, string& s, map<string, string>& ts);
    
    void escribir_tabla_codigos();

};
#endif


